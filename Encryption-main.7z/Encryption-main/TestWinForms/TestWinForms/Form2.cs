﻿using System; // Библиотека для работы с базовыми классами .NET.
using System.Text; // Библиотека для работы с текстовыми данными и StringBuilder.
using System.Windows.Forms; // Библиотека для создания оконных приложений на основе Windows Forms.

namespace TestWinForms // Определение пространства имен приложения.
{
    public partial class Form1 : Form // Определение класса Form1, наследуемого от базового класса Form.
    {
        // Массив символов русского алфавита, включая прописные и заглавные буквы.
        char[] russianAlphabet = new char[] {
           'А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ё', 'Ж', 'З', 'И', 'Й', 'К', 'Л', 'М', 'Н', 'О', 'П', 'Р', 'С', 'Т', 'У',
           'Ф', 'Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Ъ', 'Ы', 'Ь', 'Э', 'Ю', 'Я',
           'а', 'б', 'в', 'г', 'д', 'е', 'ё', 'ж', 'з', 'и', 'й', 'к', 'л', 'м', 'н', 'о', 'п', 'р', 'с', 'т', 'у',
           'ф', 'х', 'ц', 'ч', 'ш', 'щ', 'ъ', 'ы', 'ь', 'э', 'ю', 'я'
        };

        // Массив символов английского алфавита, включая прописные и заглавные буквы.
        char[] englishAlphabet = new char[] {
           'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U',
           'V', 'W', 'X', 'Y', 'Z',
           'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u',
           'v', 'w', 'x', 'y', 'z'
        };

        public Form1() // Конструктор формы.
        {
            InitializeComponent(); // Инициализация компонентов формы.
        }

        private void but_trans_Click(object sender, EventArgs e) // Обработчик события нажатия кнопки преобразования текста.
        {
            try // Начало блока обработки исключений.
            {
                // Проверка ввода ключа (должен быть целым числом).
                if (string.IsNullOrEmpty(key_code.Text) || !int.TryParse(key_code.Text, out int key))
                {
                    throw new FormatException("Ключ должен быть целым числом."); // Исключение, если ключ некорректный.
                }

                char[] userInput = text_to_trans.Text.ToCharArray(); // Преобразование текста в массив символов.

                if (type_of_trans.Text == "Перевод из зашифрованного текста в читаемый") // Если выбрано расшифрование.
                {
                    input_text.Text = decryption(userInput, key).ToString(); // Расшифрование текста и вывод результата.
                }
                else if (type_of_trans.Text == "Перевод из читаемого текста в зашифрованный") // Если выбрано шифрование.
                {
                    input_text.Text = encryption(userInput, key).ToString(); // Шифрование текста и вывод результата.
                }
                else // Если не выбран тип преобразования.
                {
                    MessageBox.Show("Выберите тип преобразования.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning); // Сообщение об ошибке.
                }
            }
            catch (FormatException ex) // Обработка исключения некорректного формата.
            {
                MessageBox.Show(ex.Message, "Ошибка ключа", MessageBoxButtons.OK, MessageBoxIcon.Error); // Вывод сообщения об ошибке.
            }
            catch (Exception ex) // Общая обработка исключений.
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error); // Сообщение об ошибке.
            }
        }

        private void copy_but_Click(object sender, EventArgs e) // Обработчик события нажатия кнопки копирования текста.
        {
            Clipboard.SetText(input_text.Text); // Копирование текста результата в буфер обмена.
        }

        // Метод для расшифрования текста с учётом ключа и алфавита.
        private StringBuilder decryption(char[] input, int key)
        {
            StringBuilder output = new StringBuilder(); // Создание объекта StringBuilder для накопления результата.
            key = NormalizeKey(key, russianAlphabet.Length); // Нормализация ключа.
            foreach (char c in input) // Перебор каждого символа во входном тексте.
            {
                // Если символ является русской буквой.
                if (Array.Exists(russianAlphabet, x => x == c))
                {
                    output.Append(ProcessCharacter(c, -key, russianAlphabet)); // Шифруем символ с учётом ключа для русского алфавита.
                }
                // Если символ является английской буквой.
                else if (Array.Exists(englishAlphabet, x => x == c))
                {
                    output.Append(ProcessCharacter(c, -key, englishAlphabet)); // Шифруем символ с учётом ключа для английского алфавита.
                }
                else // Если символ не является буквой.
                {
                    output.Append(c); // Нешифруемые символы остаются неизменными.
                }
            }
            return output; // Возвращаем результат расшифрования.
        }

        // Метод для шифрования текста с учётом ключа и алфавита.
        private StringBuilder encryption(char[] input, int key)
        {
            StringBuilder output = new StringBuilder(); // Создание объекта StringBuilder для накопления результата.
            key = NormalizeKey(key, russianAlphabet.Length); // Нормализация ключа.
            foreach (char c in input) // Перебор каждого символа во входном тексте.
            {
                // Если символ является русской буквой.
                if (Array.Exists(russianAlphabet, x => x == c))
                {
                    output.Append(ProcessCharacter(c, key, russianAlphabet)); // Шифруем символ с учётом ключа для русского алфавита.
                }
                // Если символ является английской буквой.
                else if (Array.Exists(englishAlphabet, x => x == c))
                {
                    output.Append(ProcessCharacter(c, key, englishAlphabet)); // Шифруем символ с учётом ключа для английского алфавита.
                }
                else // Если символ не является буквой.
                {
                    output.Append(c); // Нешифруемые символы остаются неизменными.
                }
            }
            return output; // Возвращаем результат шифрования.
        }

        // Метод для обработки символов с учётом ключа и алфавита.
        private char ProcessCharacter(char c, int key, char[] alphabet)
        {
            int index = Array.IndexOf(alphabet, c); // Находим индекс символа в алфавите.
            if (index != -1) // Если символ найден в алфавите.
            {
                int newIndex = (index + key) % alphabet.Length; // Вычисление нового индекса с учётом ключа.
                if (newIndex < 0) newIndex += alphabet.Length; // Корректировка для отрицательных индексов.
                return alphabet[newIndex]; // Возвращаем новый символ из алфавита.
            }
            return c; // Если символ не найден, возвращаем его без изменений.
        }

        // Метод для нормализации ключа в пределах допустимого диапазона алфавита.
        private int NormalizeKey(int key, int alphabetLength)
        {
            key = key % alphabetLength; // Приведение ключа в допустимый диапазон.
            if (key < 0) key += alphabetLength; // Коррекция для отрицательных ключей.
            return key; // Возвращаем нормализованный ключ.
        }

        private void text_to_trans_TextChanged(object sender, EventArgs e) // Обработчик события изменения текста ввода (не используется, можно удалить).
        {

        }
    }
}


